# AUX MEAN
# Private aux function aux_mean
# Description: returns mean of binomial
# Input: trials (numeric value), prob (numeric value)
# Returns: mean

aux_mean <- function(trials,prob) {
  return(trials*prob)
}
